"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CountdownTimer } from "@/components/countdown-timer"
import { LoveTimeline } from "@/components/love-timeline"
import { FloatingHearts } from "@/components/floating-hearts"
import { VenueCard } from "@/components/venue-card"
import { Section, SectionTitle } from "@/components/section"
import { EnvelopeIntro } from "@/components/envelope-intro"
import { ClosingSection } from "@/components/closing-section"
import { Heart } from "lucide-react"

export default function WeddingInvitation() {
  const [showIntro, setShowIntro] = useState(true)
  const weddingDate = new Date("September 1, 2026 18:00:00")

  return (
    <>
      {/* Envelope Opening Animation */}
      <AnimatePresence>
        {showIntro && (
          <EnvelopeIntro onComplete={() => setShowIntro(false)} />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <AnimatePresence>
        {!showIntro && (
          <motion.main 
            className="min-h-screen bg-background relative overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            {/* Background decorations */}
            <FloatingHearts />
            
            {/* Gradient overlays */}
            <div className="fixed inset-0 pointer-events-none z-0">
              <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
            </div>

            {/* Hero Section */}
            <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 z-10">
              <div className="text-center max-w-4xl mx-auto">
                {/* Tag */}
                <motion.div 
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-8"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <span className="animate-pulse">&#10024;</span>
                  <span>دعوة زفاف</span>
                  <span className="animate-pulse">&#10024;</span>
                </motion.div>

                {/* Names */}
                <motion.h1 
                  className="text-6xl sm:text-7xl lg:text-8xl font-serif text-primary mb-6 text-balance"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                >
                  محمد & مريم
                </motion.h1>

                {/* Decorative line */}
                <motion.div 
                  className="flex items-center justify-center gap-4 mb-8"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                >
                  <div className="h-px w-16 sm:w-24 bg-gradient-to-l from-primary to-transparent" />
                  <Heart className="w-5 h-5 text-primary fill-primary animate-pulse" />
                  <div className="h-px w-16 sm:w-24 bg-gradient-to-r from-primary to-transparent" />
                </motion.div>

                {/* Subtitle */}
                <motion.p 
                  className="text-lg sm:text-xl text-muted-foreground mb-4 max-w-xl mx-auto leading-relaxed text-balance"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                >
                  ليلة واحدة… لكنها بداية عمر كامل من الحكاية
                </motion.p>

                {/* Date */}
                <motion.p 
                  className="text-primary font-bold text-lg mb-10"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1 }}
                >
                  ١ سبتمبر ٢٠٢٦ — ٦:٠٠ مساءً
                </motion.p>

                {/* Countdown */}
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.2 }}
                >
                  <CountdownTimer targetDate={weddingDate} />
                </motion.div>

                {/* Scroll indicator */}
                <motion.div 
                  className="absolute bottom-8 left-1/2 -translate-x-1/2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 1.5 }}
                >
                  <motion.div 
                    className="w-6 h-10 rounded-full border-2 border-primary/30 flex items-start justify-center p-2"
                    animate={{ y: [0, 5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    <motion.div 
                      className="w-1 h-2 bg-primary rounded-full"
                      animate={{ y: [0, 4, 0], opacity: [1, 0.5, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                  </motion.div>
                </motion.div>
              </div>
            </section>

            {/* Love Journey Section */}
            <Section id="journey" className="relative z-10">
              <div className="max-w-6xl mx-auto">
                <SectionTitle subtitle="قصة حبنا من البداية إلى الأبد">
                  رحلة الحب
                </SectionTitle>
                <LoveTimeline />
              </div>
            </Section>

            {/* Venue Section */}
            <Section id="venue" className="relative z-10">
              <SectionTitle subtitle="نتشرف بحضوركم في هذا المكان المميز">
                مكان الحفل
              </SectionTitle>
              <VenueCard />
            </Section>

            {/* Closing Section */}
            <ClosingSection />
          </motion.main>
        )}
      </AnimatePresence>
    </>
  )
}
