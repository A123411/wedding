"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface EnvelopeIntroProps {
  onComplete: () => void
}

export function EnvelopeIntro({ onComplete }: EnvelopeIntroProps) {
  const [stage, setStage] = useState<"closed" | "opening" | "revealed">("closed")

  useEffect(() => {
    // Auto-start opening after a brief pause
    const timer = setTimeout(() => {
      if (stage === "closed") {
        setStage("opening")
      }
    }, 800)
    return () => clearTimeout(timer)
  }, [stage])

  useEffect(() => {
    if (stage === "opening") {
      const timer = setTimeout(() => {
        setStage("revealed")
      }, 1200)
      return () => clearTimeout(timer)
    }
  }, [stage])

  useEffect(() => {
    if (stage === "revealed") {
      const timer = setTimeout(() => {
        onComplete()
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [stage, onComplete])

  const handleClick = () => {
    if (stage === "closed") {
      setStage("opening")
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden"
        style={{ background: "linear-gradient(135deg, #fdf8f2 0%, #f5ebe0 100%)" }}
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.8 }}
      >
        {/* Decorative particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full"
              style={{
                background: i % 2 === 0 ? "#d4af37" : "#b8860b",
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -30, 0],
                opacity: [0.3, 0.6, 0.3],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>

        {/* Main envelope container */}
        <motion.div
          className="relative cursor-pointer"
          onClick={handleClick}
          whileHover={stage === "closed" ? { scale: 1.02 } : {}}
          whileTap={stage === "closed" ? { scale: 0.98 } : {}}
        >
          {/* Envelope base */}
          <motion.div
            className="relative w-80 h-56 md:w-96 md:h-64"
            animate={stage === "revealed" ? { scale: 1.1, y: -20 } : {}}
            transition={{ duration: 0.5 }}
          >
            {/* Envelope body */}
            <div 
              className="absolute inset-0 rounded-lg shadow-2xl"
              style={{ 
                background: "linear-gradient(145deg, #f5ebe0 0%, #e8dfd3 100%)",
                border: "2px solid #d4af37"
              }}
            />

            {/* Gold seal */}
            <motion.div
              className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 w-16 h-16 rounded-full flex items-center justify-center z-10"
              style={{ 
                background: "linear-gradient(135deg, #d4af37 0%, #b8860b 100%)",
                boxShadow: "0 4px 15px rgba(212, 175, 55, 0.4)"
              }}
              animate={stage !== "closed" ? { scale: 0, opacity: 0 } : { scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
              </svg>
            </motion.div>

            {/* Envelope flap (top triangle) */}
            <motion.div
              className="absolute -top-1 left-0 right-0 h-32 origin-top"
              style={{
                clipPath: "polygon(0 0, 50% 100%, 100% 0)",
                background: "linear-gradient(180deg, #f8f1e8 0%, #e8dfd3 100%)",
                borderTop: "2px solid #d4af37",
                borderLeft: "2px solid #d4af37",
                borderRight: "2px solid #d4af37",
              }}
              animate={
                stage === "closed" 
                  ? { rotateX: 0 } 
                  : { rotateX: 180 }
              }
              transition={{ duration: 0.8, ease: "easeInOut" }}
            />

            {/* Inner flap shadow */}
            <motion.div
              className="absolute top-0 left-0 right-0 h-32 origin-top pointer-events-none"
              style={{
                clipPath: "polygon(0 0, 50% 100%, 100% 0)",
                background: "linear-gradient(180deg, rgba(0,0,0,0.1) 0%, transparent 100%)",
              }}
              animate={stage !== "closed" ? { opacity: 0 } : { opacity: 1 }}
              transition={{ duration: 0.3 }}
            />

            {/* Letter peeking out */}
            <motion.div
              className="absolute left-4 right-4 top-8 bottom-4 rounded-md flex flex-col items-center justify-center p-6 text-center"
              style={{ 
                background: "#fff",
                boxShadow: "0 2px 10px rgba(0,0,0,0.1)"
              }}
              initial={{ y: 0 }}
              animate={stage === "opening" || stage === "revealed" ? { y: -60 } : { y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <motion.div
                initial={{ opacity: 0 }}
                animate={stage !== "closed" ? { opacity: 1 } : { opacity: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                <p className="text-primary font-serif text-lg mb-2">دعوة زفاف</p>
                <p className="text-foreground font-serif text-2xl font-bold" style={{ color: "#b8860b" }}>
                  محمد & مريم
                </p>
                <div className="w-16 h-0.5 bg-primary/30 mx-auto mt-3" />
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Click hint */}
          <motion.p
            className="absolute -bottom-12 left-1/2 -translate-x-1/2 text-muted-foreground text-sm whitespace-nowrap"
            initial={{ opacity: 0 }}
            animate={{ opacity: stage === "closed" ? 1 : 0 }}
            transition={{ duration: 0.3, delay: 1 }}
          >
            اضغط لفتح الدعوة
          </motion.p>
        </motion.div>

        {/* Sparkle effect on reveal */}
        {stage === "revealed" && (
          <>
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={`sparkle-${i}`}
                className="absolute w-3 h-3"
                style={{
                  left: "50%",
                  top: "50%",
                }}
                initial={{ scale: 0, x: 0, y: 0, opacity: 1 }}
                animate={{
                  scale: [0, 1, 0],
                  x: Math.cos((i * 30 * Math.PI) / 180) * 150,
                  y: Math.sin((i * 30 * Math.PI) / 180) * 150,
                  opacity: [1, 1, 0],
                }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                <svg viewBox="0 0 24 24" fill="#d4af37">
                  <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                </svg>
              </motion.div>
            ))}
          </>
        )}
      </motion.div>
    </AnimatePresence>
  )
}
