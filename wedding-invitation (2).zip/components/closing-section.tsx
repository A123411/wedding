"use client"

import { motion } from "framer-motion"

export function ClosingSection() {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div 
          className="absolute top-0 left-0 w-64 h-64 opacity-10"
          style={{
            background: "radial-gradient(circle, #d4af37 0%, transparent 70%)",
            transform: "translate(-50%, -50%)"
          }}
        />
        <div 
          className="absolute bottom-0 right-0 w-64 h-64 opacity-10"
          style={{
            background: "radial-gradient(circle, #d4af37 0%, transparent 70%)",
            transform: "translate(50%, 50%)"
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative">
        <motion.div
          className="max-w-2xl mx-auto text-center"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          {/* Decorative top element */}
          <motion.div
            className="flex items-center justify-center gap-4 mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary/50" />
            <svg className="w-8 h-8 text-primary" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary/50" />
          </motion.div>

          {/* Main quote */}
          <motion.blockquote
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <p className="font-serif text-2xl md:text-3xl text-foreground leading-relaxed mb-4">
              &ldquo;وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً&rdquo;
            </p>
            <cite className="text-muted-foreground text-sm not-italic">
              سورة الروم - الآية ٢١
            </cite>
          </motion.blockquote>

          {/* Divider */}
          <motion.div
            className="w-24 h-1 mx-auto rounded-full mb-8"
            style={{ background: "linear-gradient(90deg, transparent, #d4af37, transparent)" }}
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          />

          {/* Personal message */}
          <motion.div
            className="space-y-4 mb-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
          >
            <p className="text-foreground text-lg leading-relaxed">
              نحن سعداء بأن نشارككم هذه اللحظات الجميلة
            </p>
            <p className="text-muted-foreground leading-relaxed">
              حضوركم يُسعدنا ويُكمل فرحتنا. نتمنى أن نراكم في هذا اليوم المميز لنحتفل معًا ببداية رحلة جديدة مليئة بالحب والسعادة.
            </p>
          </motion.div>

          {/* Couple names */}
          <motion.div
            className="mb-10"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
          >
            <p className="font-serif text-3xl md:text-4xl font-bold" style={{ color: "#b8860b" }}>
              محمد & مريم
            </p>
          </motion.div>

          {/* Final thank you */}
          <motion.div
            className="relative inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            viewport={{ once: true }}
          >
            <div 
              className="px-8 py-4 rounded-full"
              style={{ 
                background: "linear-gradient(135deg, rgba(212, 175, 55, 0.1) 0%, rgba(184, 134, 11, 0.1) 100%)",
                border: "1px solid rgba(212, 175, 55, 0.3)"
              }}
            >
              <p className="text-primary font-medium text-lg">
                شكرًا لكم من القلب
              </p>
            </div>
          </motion.div>

          {/* Decorative bottom hearts */}
          <motion.div
            className="flex items-center justify-center gap-3 mt-12"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            viewport={{ once: true }}
          >
            {[0.6, 0.8, 1, 0.8, 0.6].map((scale, i) => (
              <motion.svg
                key={i}
                className="text-primary/40"
                style={{ width: 16 * scale, height: 16 * scale }}
                viewBox="0 0 24 24"
                fill="currentColor"
                animate={{ 
                  y: [0, -3, 0],
                  opacity: [0.4, 0.6, 0.4]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.2
                }}
              >
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
              </motion.svg>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Footer */}
      <motion.footer
        className="mt-16 pt-8 border-t border-border/50"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.9 }}
        viewport={{ once: true }}
      >
        <p className="text-center text-muted-foreground text-sm">
          صُنع بكل حب لأجمل يوم في حياتنا
        </p>
      </motion.footer>
    </section>
  )
}
