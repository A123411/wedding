"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export function CountdownTimer({ targetDate }: { targetDate: Date }) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - new Date().getTime()

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [targetDate])

  if (!mounted) return null

  const timeUnits = [
    { value: timeLeft.days, label: "يوم" },
    { value: timeLeft.hours, label: "ساعة" },
    { value: timeLeft.minutes, label: "دقيقة" },
    { value: timeLeft.seconds, label: "ثانية" },
  ]

  return (
    <div className="flex justify-center gap-3 sm:gap-4 direction-rtl">
      {timeUnits.map((unit, index) => (
        <motion.div
          key={unit.label}
          className="group relative"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          whileHover={{ y: -4 }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="relative bg-card/80 backdrop-blur-sm px-4 py-4 sm:px-6 sm:py-5 rounded-2xl border border-border/50 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="relative h-10 sm:h-12 overflow-hidden">
              <AnimatePresence mode="popLayout">
                <motion.span 
                  key={unit.value}
                  className="block text-3xl sm:text-4xl font-bold text-primary tabular-nums"
                  initial={{ y: -40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 40, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  {unit.value.toString().padStart(2, "0")}
                </motion.span>
              </AnimatePresence>
            </div>
            <span className="block text-xs sm:text-sm text-muted-foreground mt-1 font-medium">
              {unit.label}
            </span>
          </div>
        </motion.div>
      ))}
    </div>
  )
}
